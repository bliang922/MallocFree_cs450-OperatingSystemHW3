#include "types.h"
#include "stat.h"
#include "user.h"


int 
main(void)
{
//error test
char * block1=malloc(4088);
printf(1,"\nnot allocated virtual address is : %p  ",block1+4096);
if(uv2p(block1+4096)<0)
   printf(1,"input virtual address not exist in page table");

//Test1
int a[5]={1,2,3,4,5};
int i;
for(i=0; i<5; i++){
	printf(1,"\n a[%d] virtual address is: %p  ",i, &(a[i]));
	if(uv2p((char*)(a+i))<0)
   	printf(1,"input virtual address not exist in page table");

}

//Test2
char c = 'a';
printf(1,"\n c virtual address is: %p  ",&c);
if(uv2p(&c)<0)
   printf(1,"input virtual address not exist in page table");


exit();
}
