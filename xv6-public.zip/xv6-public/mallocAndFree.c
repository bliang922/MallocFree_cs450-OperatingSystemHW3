#include "types.h"
#include "stat.h"
#include "user.h"


int 
main(void)
{

char* block1=malloc(4088);
char* block2=malloc(4088);
char* block3=malloc(4088);
char* block4;
char* block5;


printf(1,"\nblock1 virtual address is: %p ",block1);
if(uv2p(block1)<0)
   printf(1,"input virtual address not exist in page table");

printf(1,"\nblock2 virtual address is: %p ",block2);
if(uv2p(block2)<0)
   printf(1,"input virtual address not exist in page table");

printf(1,"\nblock3 virtual address is: %p ",block3);
if(uv2p(block3)<0)
   printf(1,"input virtual address not exist in page table");

free(block2);
block4=malloc(100);
printf(1,"\nfree(block2) and block4=malloc(100)");

printf(1,"\nblock4 virtual address is: %p ",block4);
if(uv2p(block4)<0)
   printf(1,"input virtual address not exist in page table");

free(block4);
free(block3);
block5=malloc(4088);
printf(1,"\nfree(block3) free(block4) and block5=malloc(4088)");

printf(1,"\nblock5 virtual address is: %p ",block5);
if(uv2p(block5)<0)
   printf(1,"input virtual address not exist in page table");

free(block1);
free(block5);


exit();
}
